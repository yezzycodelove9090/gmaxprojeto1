
import React, { useState } from 'react';
import { Send, ChevronDown } from 'lucide-react';

const QuoteSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    whatsapp: '',
    services: [] as string[],
    message: ''
  });
  const [isExpanded, setIsExpanded] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleServiceChange = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const servicesList = formData.services.join(', ');
    const message = `Olá, me chamo ${formData.name}. 
Quero solicitar um orçamento para: *${servicesList}*. 
Meu WhatsApp é: ${formData.whatsapp}. 
Detalhes: ${formData.message}`;

    window.open(`https://wa.me/5518996221422?text=${encodeURIComponent(message)}`, '_blank');

    // Resetar formulário
    setFormData({
      name: '',
      whatsapp: '',
      services: [],
      message: ''
    });
    setIsExpanded(false);
  };

  const handleFormClick = () => {
    if (!isExpanded) {
      setIsExpanded(true);
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-primary mb-4">
            Solicite um Orçamento
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Selecione os serviços que você precisa e receba seu orçamento personalizado
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div 
            className={`bg-white rounded-2xl shadow-xl transition-all duration-500 ease-in-out cursor-pointer ${
              isExpanded ? 'p-8' : 'p-6 hover:shadow-2xl'
            }`}
            onClick={handleFormClick}
          >
            {!isExpanded ? (
              <div className="text-center">
                <div className="flex items-center justify-center space-x-3">
                  <Send className="w-6 h-6 text-primary" />
                  <h3 className="text-xl font-semibold text-gray-800">
                    Clique aqui para solicitar seu orçamento
                  </h3>
                  <ChevronDown className="w-5 h-5 text-primary animate-bounce" />
                </div>
                <p className="text-gray-600 mt-2">
                  Formulário rápido e fácil
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6" onClick={(e) => e.stopPropagation()}>
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <label htmlFor="whatsapp" className="block text-sm font-medium text-gray-700 mb-2">
                    WhatsApp *
                  </label>
                  <input
                    type="tel"
                    id="whatsapp"
                    name="whatsapp"
                    value={formData.whatsapp}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="(18) 99999-9999"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-4">
                    Quais serviços? *
                  </label>
                  <div className="space-y-3">
                    {['Caçamba', 'Container', 'Escritório', 'Banheiros', 'Munck'].map((service) => (
                      <label key={service} className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.services.includes(service)}
                          onChange={() => handleServiceChange(service)}
                          className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                        />
                        <span className="text-gray-700">{service}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Mensagem
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="Descreva detalhes do seu projeto..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={formData.services.length === 0}
                  className="w-full bg-primary text-white py-4 rounded-lg font-semibold text-lg hover:bg-blue-800 transition-all duration-300 hover:scale-105 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Enviar Solicitação
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuoteSection;
