
import React from 'react';
import Header from './Header';
import Footer from './Footer';
import WhatsAppButton from './WhatsAppButton';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface ProductPageProps {
  title: string;
  heroImage: string;
  productImage: string;
  description: string;
  whatsappNumber: string;
  whatsappMessage: string;
}

const ProductPage: React.FC<ProductPageProps> = ({
  title,
  heroImage,
  productImage,
  description,
  whatsappNumber,
  whatsappMessage
}) => {
  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Banner */}
      <section className="relative h-[60vh] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white px-4 max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-6xl font-bold mb-4">
              {title}
            </h1>
          </div>
        </div>
      </section>

      {/* Product Content */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Product Image */}
            <div className="space-y-6">
              <img
                src={productImage}
                alt={title}
                className="w-full rounded-2xl shadow-lg"
              />
            </div>

            {/* Product Description */}
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-primary mb-6">
                {title}
              </h2>
              <div className="text-lg text-gray-700 leading-relaxed mb-8">
                {description.split('\n').map((paragraph, index) => (
                  <p key={index} className="mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Interessado neste produto?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Entre em contato conosco e solicite seu orçamento personalizado
          </p>

          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <a
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-700 transition-all duration-300 hover:scale-105"
            >
              Solicitar Orçamento
            </a>

            <Link
              to="/servicos"
              className="bg-secondary text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar para Serviços
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default ProductPage;
