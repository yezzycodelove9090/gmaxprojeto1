import React from 'react';
import { Truck, Clock, Shield, Award } from 'lucide-react';

const AboutSection = () => {
  const features = [
    {
      icon: <Truck className="w-6 h-6" />,
      title: "Frota própria e moderna",
      description: "Equipamentos novos e bem conservados"
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Atendimento ágil", 
      description: "Resposta rápida e entrega no prazo"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Suporte total durante a obra",
      description: "Acompanhamento completo do projeto"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Compromisso com prazos",
      description: "Pontualidade e confiabilidade sempre"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Texto */}
          <div className="animate-slide-in-left">
            <h2 className="text-4xl lg:text-5xl font-bold text-primary mb-6">
              Quem Somos
            </h2>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Mais de 10 anos entregando soluções inteligentes para sua obra.
              Somos especialistas em locação de Munck, Caçamba, Containers e Banheiros. 
              Nossa missão é entregar segurança, agilidade e confiança para obras, 
              empresas e indústrias.
            </p>

            {/* Features */}
            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div 
                  key={index}
                  className="flex items-start space-x-3 p-4 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                >
                  <div className="bg-secondary rounded-full p-2 text-primary flex-shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Imagem */}
          <div className="animate-slide-in-right">
            <div className="relative">
              <img
                src="/lovable-uploads/faixada01.jpeg"
                alt="Frota GMAX em operação"
                className="rounded-xl w-full h-[500px] object-cover shadow-2xl"
              />
              <div className="absolute bottom-0 left-0 w-full h-24 bg-white/1 backdrop-blur-xl rounded-b-xl"></div>
<div className="absolute inset-0 bg-black/2 rounded-xl"></div>

              <div className="absolute -bottom-6 -left-6 bg-secondary text-primary p-6 rounded-xl shadow-lg">
                <div className="text-3xl font-bold">+10</div>
                <div className="text-sm font-semibold">Anos de Experiência</div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
