
import React from 'react';
import { Link } from 'react-router-dom';

const ServicesSection = () => {
  const services = [
    {
      id: 1,
      title: "Caçamba",
      slug: "cacamba",
      image: "/lovable-uploads/caçambafoto.jpg",
      description: "Descarte de entulho rápido, prático e seguro. Entregamos e retiramos com agilidade."
    },
    
    {
      id: 2,
      title: "Container",
      slug: "container", 
      image: "/lovable-uploads/conteiner01.jpeg",
      description: "Armazenamento seguro para obras e empresas,                 Clique em saiba mais para ver variações."
    },
    {
      id: 3,
      title: "Caminhão Munck",
      slug: "caminhao-munck",
      image: "/lovable-uploads/caminhaocapa.jpeg",
      description: "Içamento e transporte de cargas pesadas com total segurança."
    },
    {
      id: 4,
      title: "Banheiros",
      slug: "banheiro",
      image: "/lovable-uploads/banheirocapa.jpeg",
      description: "Solução sanitária prática para obras e eventos."
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-primary mb-4">
           Produtos e Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Soluções completas para sua obra com qualidade e segurança
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Link 
              key={service.id}
              to={`/servicos/${service.slug}`}
              className={`bg-white rounded-2xl overflow-hidden shadow-lg hover-lift cursor-pointer transition-all duration-300 ${
                index % 2 === 0 ? 'animate-slide-in-left' : 'animate-slide-in-right'
              }`}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={`Locação de ${service.title} GMAX`}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute inset-0 bg-black/20"></div>
                <h3 className="absolute bottom-4 left-4 text-white font-bold text-xl">
                  {service.title}
                </h3>
              </div>
              <div className="p-6">
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
                <div className="mt-4 text-primary font-semibold hover:text-secondary transition-colors duration-200">
                  Saiba mais →
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
