
import React, { useState } from 'react';
import { Phone, MapPin, Clock, Send } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    whatsapp: '',
    reason: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const message = `Olá, me chamo ${formData.name}. 
Motivo do contato: *${formData.reason}*. 
Meu WhatsApp é: ${formData.whatsapp}. 
Mensagem: ${formData.message}`;

    window.open(`https://wa.me/5518996221422?text=${encodeURIComponent(message)}`, '_blank');

    // Resetar formulário
    setFormData({
      name: '',
      whatsapp: '',
      reason: '',
      message: ''
    });
  };

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-primary mb-4">
            Entre em Contato
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Pronto para atender sua obra com agilidade e qualidade
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Informações de Contato */}
          <div className="animate-slide-in-left">
            <h3 className="text-2xl font-bold text-primary mb-8">
              Informações de Contato
            </h3>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-secondary rounded-full p-3 text-primary">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg text-primary mb-2">Telefones</h4>
                   <p className="text-gray-700 mb-1">WhatsApp: (18) 998181585 </p>
                  <p className="text-gray-700 mb-1">WhatsApp: (18) 99622-1422</p>
                  <p className="text-gray-700">Fixo: (18) 3281-1585</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-secondary rounded-full p-3 text-primary">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg text-primary mb-2">Endereço</h4>
                  <p className="text-gray-700">R. Emídio de Lima Paes, 2-71 - Pres. Epitácio, SP, 19475196</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-secondary rounded-full p-3 text-primary">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg text-primary mb-2">Horário</h4>
                  <p className="text-gray-700">Segunda a Sexta: 7h às 18h</p>
                  <p className="text-gray-700">Sábado: 7h às 12h</p>
                  <p className="text-gray-700">Emergências: 24h</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <a
                href="https://wa.me/1832811585?text=Olá! Gostaria de fazer um orçamento para locação de equipamentos."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-green-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-700 transition-all duration-300 hover:scale-105 w-full md:w-auto justify-center"
              >
                <Phone className="w-5 h-5 mr-2" />
                Falar no WhatsApp
              </a>
            </div>
          </div>

          {/* Formulário de Contato */}
          <div className="animate-slide-in-right">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-primary mb-6">
                Formulário de Contato
              </h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <label htmlFor="whatsapp" className="block text-sm font-medium text-gray-700 mb-2">
                    WhatsApp *
                  </label>
                  <input
                    type="tel"
                    id="whatsapp"
                    name="whatsapp"
                    value={formData.whatsapp}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="(18) 99999-9999"
                  />
                </div>

                <div>
                  <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-2">
                    Motivo do Contato *
                  </label>
                  <select
                    id="reason"
                    name="reason"
                    value={formData.reason}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                  >
                    <option value="">Selecione o motivo</option>
                    <option value="Comercial">Comercial</option>
                    <option value="Financeiro">Financeiro</option>
                    <option value="Dúvidas">Dúvidas</option>
                    <option value="Reclamações">Reclamações</option>
                    <option value="Elogios">Elogios</option>
                    <option value="Sugestão">Sugestão</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Mensagem *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors duration-200"
                    placeholder="Descreva os detalhes do seu contato..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-primary text-white py-4 rounded-lg font-semibold text-lg hover:bg-blue-800 transition-all duration-300 hover:scale-105 flex items-center justify-center"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Enviar Mensagem
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
