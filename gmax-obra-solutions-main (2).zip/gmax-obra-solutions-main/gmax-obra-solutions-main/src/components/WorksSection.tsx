
import React from 'react';

const WorksSection = () => {
  const works = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Caminhão Munck GMAX içando materiais em obra"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Caçamba GMAX posicionada em canteiro de obras"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1566207462340-1b71ee2b40d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Container GMAX instalado para armazenamento"
    },
    {
      id: 4,
      image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Banheiro químico GMAX em obra"
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Frota GMAX completa de equipamentos"
    },
    {
      id: 6,
      image: "https://images.unsplash.com/photo-1487887235947-a955ef187fcc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      alt: "Operação de içamento com Munck GMAX"
    }
  ];

  const partnerLogos = [
    { id: 1, name: "Empresa 1", logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=120&h=60&fit=crop" },
    { id: 2, name: "Empresa 2", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=120&h=60&fit=crop" },
    { id: 3, name: "Empresa 3", logo: "https://images.unsplash.com/photo-1560472355-536de3962603?w=120&h=60&fit=crop" },
    { id: 4, name: "Empresa 4", logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=120&h=60&fit=crop" },
    { id: 5, name: "Empresa 5", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=120&h=60&fit=crop" },
    { id: 6, name: "Empresa 6", logo: "https://images.unsplash.com/photo-1560472355-536de3962603?w=120&h=60&fit=crop" }
  ];

  return (
    <section id="works" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-primary mb-4">
            Trabalhos Realizados
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Nossa frota em ação, entregando soluções para diversos tipos de obras
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {works.map((work, index) => (
            <div 
              key={work.id}
              className={`group relative overflow-hidden rounded-2xl shadow-lg hover-lift ${
                index % 2 === 0 ? 'animate-slide-in-left' : 'animate-slide-in-right'
              }`}
            >
              <div className="aspect-w-16 aspect-h-12 bg-gray-200">
                <img
                  src={work.image}
                  alt={work.alt}
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                    <p className="text-white text-sm font-medium">
                      {work.alt}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 mb-16">
          <a
            href="https://wa.me/5518996221422?text=Olá! Gostaria de conhecer mais sobre os trabalhos da GMAX."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-800 transition-all duration-300 hover:scale-105"
          >
            Ver Mais Trabalhos
          </a>
        </div>

        {/* Slider de Logos dos Parceiros */}
        <div className="mt-16 bg-gray-50 py-12 overflow-hidden">
          <div className="relative">
            <div className="flex animate-scroll">
              {[...partnerLogos, ...partnerLogos].map((logo, index) => (
                <div
                  key={`${logo.id}-${index}`}
                  className="flex-shrink-0 mx-8 flex items-center justify-center"
                >
                  <img
                    src={logo.logo}
                    alt={logo.name}
                    className="h-12 w-auto max-w-[120px] object-contain grayscale hover:grayscale-0 transition-all duration-300"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        
        .animate-scroll {
          animation: scroll 20s linear infinite;
        }
      `}</style>
    </section>
  );
};

export default WorksSection;
