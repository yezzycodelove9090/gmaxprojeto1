import React, { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

const HeroSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentText, setCurrentText] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  const texts = [
    "Soluções que movem sua obra.",
    "Logística pesada, leve pra você.",
    "Munck, Containers, Caçambas e Banheiros.",
    "Quando a carga é pesada, a solução é GMAX."
  ];

  // 🔥 Imagens diferentes pra desktop e mobile
  const desktopImages = [
    "/lovable-uploads/fotocaminhao.jpeg",
    "/lovable-uploads/fotocaminhao2.jpeg",
    "/lovable-uploads/fotocaminhao3.jpeg",
    "/lovable-uploads/11dce0fd-f016-4d65-aa55-b73106184369.png",
    "/lovable-uploads/a535ca77-d08c-4b65-8302-c43bfad3a52d.png"
     
  ];

  const mobileImages = [
    "/lovable-uploads/mobile1.jpeg",
    "/lovable-uploads/fotocaminhao.jpeg",
    "/lovable-uploads/11dce0fd-f016-4d65-aa55-b73106184369.png",
    "/lovable-uploads/a535ca77-d08c-4b65-8302-c43bfad3a52d.png",
    "/lovable-uploads/e52af95e-1697-4a21-aefd-3018f795972a.png"
  ];

  const images = isMobile ? mobileImages : desktopImages;

  // 🔥 Detectar se é mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // 🔄 Slide das imagens
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % images.length);
    }, 3500); // Slide mais rápido

    return () => clearInterval(slideInterval);
  }, [images.length]);

  // 🔄 Slide dos textos
  useEffect(() => {
    const textInterval = setInterval(() => {
      setCurrentText((prev) => (prev + 1) % texts.length);
    }, 4000);

    return () => clearInterval(textInterval);
  }, []);

  const scrollToServices = () => {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      servicesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative h-screen overflow-hidden">
      {/* Background Slider */}
      <div className="absolute inset-0">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={image}
              alt={`GMAX equipamentos slide ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="text-left text-white px-4 max-w-4xl ml-10">
          <div className="h-20 md:h-24 flex items-center mb-8">
            <p
              key={currentText}
              className="text-xl md:text-2xl lg:text-3xl font-light typing-animation max-w-3xl"
            >
              {texts[currentText]}
            </p>
          </div>

          <div className="space-y-4 md:space-y-0 md:space-x-6 md:flex">
            <button
              onClick={scrollToServices}
              className="bg-secondary text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all duration-300 hover:scale-105 block md:inline-block w-full md:w-auto"
            >
              Saiba Mais
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <ChevronDown size={32} />
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors duration-300 ${
              index === currentSlide ? 'bg-secondary' : 'bg-white/50'
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSection;
