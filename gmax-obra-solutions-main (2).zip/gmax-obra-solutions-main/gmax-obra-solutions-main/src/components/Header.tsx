import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  const location = useLocation();

  const productCategories = {
    banheiros: [
      { name: 'Banheiro Hidráulico', slug: 'banheiro-hidraulico' },
      { name: 'Banheiro Químico', slug: 'banheiro-quimico' },
    ],
    cacambas: [
      { name: 'Caçamba para Entulho', slug: 'cacamba-entulho' },
    ],
    containers: [
      { name: 'Container Almoxarifado', slug: 'container-almoxarifado' },
      { name: 'Container Depósito', slug: 'container-deposito' },
      { name: 'Container Depósito Mini', slug: 'container-deposito-mini' },
      { name: 'Escritório Small', slug: 'escritorio-small' },
    ],
    munck: [
      { name: 'Munck – Caminhão com Guindaste', slug: 'munck' },
    ]
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.products-dropdown')) {
        setIsProductsOpen(false);
        setActiveSubmenu(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const scrollToSection = (sectionId: string) => {
    // Close mobile menu first
    setIsMobileMenuOpen(false);
    
    // If not on home page, navigate to home first
    if (location.pathname !== '/') {
      window.location.href = `/#${sectionId}`;
      return;
    }

    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate header height for offset
      const headerElement = document.querySelector('header');
      const headerHeight = headerElement ? headerElement.offsetHeight : 80;
      
      // Calculate position with offset
      const elementPosition = element.offsetTop - headerHeight - 20; // Extra 20px padding
      
      window.scrollTo({
        top: Math.max(0, elementPosition),
        behavior: 'smooth'
      });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
    setIsMobileMenuOpen(false);
  };

  const toggleProductsMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsProductsOpen(!isProductsOpen);
    setActiveSubmenu(null);
  };

  const toggleSubmenu = (category: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveSubmenu(activeSubmenu === category ? null : category);
  };

  const handleProductClick = () => {
    setIsProductsOpen(false);
    setActiveSubmenu(null);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-primary shadow-lg backdrop-blur-md border-b border-secondary/20' 
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20 lg:h-24">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" onClick={scrollToTop} className="block">
              <img 
                src="/lovable-uploads/gmaxlogo.svg" 
                alt="GMAX Locação de Equipamentos" 
                className="h-[50px] md:h-[60px] lg:h-[70px] w-auto hover:scale-105 transition-transform duration-300"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link 
              to="/"
              onClick={scrollToTop}
              className="text-white hover:text-secondary transition-colors duration-200 font-medium"
            >
              Início
            </Link>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-white hover:text-secondary transition-colors duration-200 font-medium"
            >
              Quem Somos
            </button>
            
            {/* Products Dropdown */}
            <div className="relative products-dropdown">
              <button
                onClick={toggleProductsMenu}
                className="text-white hover:text-secondary transition-colors duration-200 font-medium flex items-center gap-1"
              >
                Produtos e Serviços
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isProductsOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isProductsOpen && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl border z-50">
                  <div className="py-2">
                    {/* Banheiros */}
                    <div className="relative">
                      <button
                        onClick={(e) => toggleSubmenu('banheiros', e)}
                        className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 hover:text-primary transition-colors duration-200 flex items-center justify-between"
                      >
                        Banheiros
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeSubmenu === 'banheiros' ? 'rotate-180' : '-rotate-90'}`} />
                      </button>
                      
                      {activeSubmenu === 'banheiros' && (
                        <div className="bg-gray-50 border-t border-gray-200">
                          {productCategories.banheiros.map((product) => (
                            <Link
                              key={product.slug}
                              to={`/produtos/${product.slug}`}
                              className="block px-8 py-2 text-gray-600 hover:bg-gray-100 hover:text-primary transition-colors duration-200"
                              onClick={handleProductClick}
                            >
                              {product.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Caçambas */}
                    <div className="relative">
                      <button
                        onClick={(e) => toggleSubmenu('cacambas', e)}
                        className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 hover:text-primary transition-colors duration-200 flex items-center justify-between"
                      >
                        Caçambas
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeSubmenu === 'cacambas' ? 'rotate-180' : '-rotate-90'}`} />
                      </button>
                      
                      {activeSubmenu === 'cacambas' && (
                        <div className="bg-gray-50 border-t border-gray-200">
                          {productCategories.cacambas.map((product) => (
                            <Link
                              key={product.slug}
                              to={`/produtos/${product.slug}`}
                              className="block px-8 py-2 text-gray-600 hover:bg-gray-100 hover:text-primary transition-colors duration-200"
                              onClick={handleProductClick}
                            >
                              {product.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Containers */}
                    <div className="relative">
                      <button
                        onClick={(e) => toggleSubmenu('containers', e)}
                        className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 hover:text-primary transition-colors duration-200 flex items-center justify-between"
                      >
                        Containers
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeSubmenu === 'containers' ? 'rotate-180' : '-rotate-90'}`} />
                      </button>
                      
                      {activeSubmenu === 'containers' && (
                        <div className="bg-gray-50 border-t border-gray-200">
                          {productCategories.containers.map((product) => (
                            <Link
                              key={product.slug}
                              to={`/produtos/${product.slug}`}
                              className="block px-8 py-2 text-gray-600 hover:bg-gray-100 hover:text-primary transition-colors duration-200"
                              onClick={handleProductClick}
                            >
                              {product.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Munck */}
                    <div className="relative">
                      <button
                        onClick={(e) => toggleSubmenu('munck', e)}
                        className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 hover:text-primary transition-colors duration-200 flex items-center justify-between"
                      >
                        Munck
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeSubmenu === 'munck' ? 'rotate-180' : '-rotate-90'}`} />
                      </button>
                      
                      {activeSubmenu === 'munck' && (
                        <div className="bg-gray-50 border-t border-gray-200">
                          {productCategories.munck.map((product) => (
                            <Link
                              key={product.slug}
                              to={`/produtos/${product.slug}`}
                              className="block px-8 py-2 text-gray-600 hover:bg-gray-100 hover:text-primary transition-colors duration-200"
                              onClick={handleProductClick}
                            >
                              {product.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <button 
              onClick={() => scrollToSection('works')}
              className="text-white hover:text-secondary transition-colors duration-200 font-medium"
            >
              Trabalhos
            </button>
            <button 
              onClick={() => scrollToSection('testimonials')}
              className="text-white hover:text-secondary transition-colors duration-200 font-medium"
            >
              Depoimentos
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-white hover:text-secondary transition-colors duration-200 font-medium"
            >
              Contato
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-white p-2"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-primary border-t border-secondary/20">
            <nav className="py-4 space-y-2">
              <Link 
                to="/"
                onClick={scrollToTop}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Início
              </Link>
              <button 
                onClick={() => scrollToSection('about')}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Quem Somos
              </button>
              <Link 
                to="/servicos"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Serviços
              </Link>
              <button 
                onClick={() => scrollToSection('works')}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Trabalhos
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Depoimentos
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="block w-full text-left px-4 py-2 text-white hover:text-secondary transition-colors duration-200"
              >
                Contato
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
