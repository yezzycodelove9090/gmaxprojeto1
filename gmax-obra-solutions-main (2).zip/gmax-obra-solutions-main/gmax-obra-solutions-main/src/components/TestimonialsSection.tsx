
import React from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";

const TestimonialsSection = () => {
  const testimonialImages = [
    {
      id: 1,
      image: "lovable-uploads/depoimento2.jpeg",
      alt: "Depoimento cliente 1"
    },
    {
      id: 2,
      image: "lovable-uploads/depoimento3.jpeg",
      alt: "Depoimento cliente 2"
    },
    {
      id: 3,
      image: "lovable-uploads/depoimento4.jpeg",
      alt: "Depoimento cliente 3"
    },
    {
      id: 4,
      image: "lovable-uploads/depoimento5.jpeg",
      alt: "Depoimento cliente 4"
    }
  ];

  return (
    <section id="testimonials" className="py-20 text-white relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: `url("/lovable-uploads/88604bf4-ad25-4f4f-ac74-8e947191e5cb.png")`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat'
        }}
      ></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
            Depoimentos
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            O que nossos clientes falam sobre nossos serviços
          </p>
        </div>

        <div className="max-w-md mx-auto">
          <Carousel className="w-full">
            <CarouselContent>
              {testimonialImages.map((testimonial) => (
                <CarouselItem key={testimonial.id}>
                  <div className="flex justify-center">
                    <div className="w-[280px] h-[500px] bg-white rounded-[25px] shadow-2xl p-1 border-4 border-gray-800">
                      <img
                        src={testimonial.image}
                        alt={testimonial.alt}
                        className="w-full h-full object-cover rounded-[20px]"
                      />
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-4" />
            <CarouselNext className="right-4" />
          </Carousel>
        </div>

        <div className="text-center mt-12">
          <a
            href="https://wa.me/5518996221422?text=Olá! Gostaria de solicitar um orçamento."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-secondary text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all duration-300 hover:scale-105"
          >
            Faça seu Orçamento
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
