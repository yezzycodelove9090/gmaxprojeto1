import React from 'react';
import { Facebook, Instagram, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="text-white py-12 relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: `url("/lovable-uploads/88604bf4-ad25-4f4f-ac74-8e947191e5cb.png")`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat'
        }}
      ></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Logo and Description */}
          <div>
            <div className="mb-4">
              <Link to="/">
                <img 
                  src="/lovable-uploads/gmaxlogo.svg" 
                  alt="GMAX Locação de Equipamentos" 
                  className="h-16 w-auto hover:scale-105 transition-transform duration-300"
                />
              </Link>
            </div>
            <p className="text-white/80 leading-relaxed mb-6">
              Mais de 10 anos oferecendo soluções em locação de equipamentos 
              para obras e empresas em Presidente Epitácio e região.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://www.facebook.com/containerlocacaogmax/?locale=pt_BR" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-secondary hover:text-primary p-2 rounded-full transition-all duration-300"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="https://www.instagram.com/gmaxlocacao?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-secondary hover:text-primary p-2 rounded-full transition-all duration-300"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-bold mb-6">Nossos Serviços</h3>
            <ul className="space-y-3 text-white/80">
              <li>
                <Link to="/servicos/cacamba" className="hover:text-secondary transition-colors duration-200">
                  Locação de Caçamba
                </Link>
              </li>
              <li>
                <Link to="/servicos/container" className="hover:text-secondary transition-colors duration-200">
                  Locação de Container
                </Link>
              </li>
              <li>
                <Link to="/servicos/caminhao-munck" className="hover:text-secondary transition-colors duration-200">
                  Caminhão Munck
                </Link>
              </li>
              <li>
                <Link to="/servicos/banheiro" className="hover:text-secondary transition-colors duration-200">
                  Banheiro Químico e Hidráulico
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-6">Contato</h3>
            <div className="space-y-4 text-white/80">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-secondary" />
                <div>
                  <p>WhatsApp: (18) 998181585</p>
                  <p>WhatsApp: (18) 99622-1422</p>
                  <p>Fixo: (18) 3281-1585</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-secondary" />
                <p>contato@gmax.com.br</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 text-secondary mt-1">📍</div>
                <p>R. Emídio de Lima Paes, 2-71 - Pres. Epitácio, SP, 19475196</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 mt-8 pt-8 text-center">
          <p className="text-white/60">
            © 2025 GMAX Locação de Equipamentos – Todos os direitos reservados.
          </p>
          <p className="text-white/40 text-sm mt-2">
            Desenvolvido por Miguel
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
