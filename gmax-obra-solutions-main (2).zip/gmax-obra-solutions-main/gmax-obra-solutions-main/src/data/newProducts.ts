
export interface NewProduct {
  name: string;
  slug: string;
  heroImage: string;
  productImage: string;
  description: string;
  whatsappNumber: string;
  whatsappMessage: string;
}

export const newProducts: NewProduct[] = [
  {
    name: 'Banheiro Hidráulico',
    slug: 'banheiro-hidraulico',
    heroImage: '/lovable-uploads/banheirocapa.jpeg',
    productImage: '/lovable-uploads/banheirocapa.jpeg',
    description: `Banheiro Hidráulico. Medida 1 x 1,10.
Trava interna e externa e instalação hidráulica.
Indicado para construções residenciais e comerciais, eventos, festas particulares, entre outros.
Pela sua praticidade na instalação, não necessitando de limpeza, e de fácil mobilidade, sua diversidade permite utilizar ele em qualquer ambiente.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Banheiro Hidráulico.'
  },
  {
    name: 'Banheiro Químico',
    slug: 'banheiro-quimico',
    heroImage: '/lovable-uploads/banheirocapa.jpeg',
    productImage: '/lovable-uploads/banheirocapa.jpeg',
    description: `Banheiro Químico. Medida 1,20 x 1,20.
Fabricado em Polietileno, trava interna e externa.
Indicado para construção civil, festas particulares e eventos em geral.
Por não exigir uma pré-instalação se torna prático e viável em qualquer ambiente.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Banheiro Químico.'
  },
  {
    name: 'Caçamba para Entulho',
    slug: 'cacamba-entulho',
    heroImage: '/lovable-uploads/caçambafoto.jpg',
    productImage: '/lovable-uploads/caçambafoto.jpg',
    description: `Caçambas para entulho. Capacidade 4m³.
Caçamba estacionária, utilizada para transporte de entulhos e resíduos diversos.
Descartadas em local indicado de acordo com o resíduo descartado.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Caçamba para Entulho.'
  },
  {
    name: 'Container Almoxarifado',
    slug: 'container-almoxarifado',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Utilizado para uma armazenamento segura e durável, oferece a possibilidade de armazenagem de uma ampla variedade de materiais e equipamentos de forma organizada.
Composto por prateleiras que são essenciais para organização dos materiais.
Medidas:
- 10 pés
- 20 pés
- 40 pés`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Almoxarifado.'
  },
  {
    name: 'Container Depósito',
    slug: 'container-deposito',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Utilizado para um armazenamento seguro e durável, oferece a possibilidade de armazenagem de uma ampla variedade de materiais e equipamentos de forma organizada.
Vão livre que possibilita a armazenagem de grandes equipamentos.
Medidas:
- 10 pés
- 20 pés
- 40 pés`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Depósito.'
  },
  {
    name: 'Container Depósito Mini',
    slug: 'container-deposito-mini',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Utilizado para uma armazenamento segura e durável, oferece a possibilidade de armazenagem de uma ampla variedade de materiais e equipamentos de forma organizada.
Composto por 02 chaves tetra e um porta cadeado.
Medidas: 3 x 1,5`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Depósito Mini.'
  },
  {
    name: 'Escritório Small',
    slug: 'escritorio-small',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Medida: 3,00 x 2,00 x 2,30
Fabricado em isopainel (painel de câmara fria)
Fechadura interna, tomadas e interruptores, ar condicionado, luminárias, janela de vidro temperado, assoalho de compensado naval.
Ótima opção para quem busca conforto para executar suas tarefas e realizar atendimentos em um espaço reduzido.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Escritório Small.'
  },
  {
    name: 'Munck – Caminhão com Guindaste',
    slug: 'munck',
    heroImage: '/lovable-uploads/caminhaocapa.jpeg',
    productImage: '/lovable-uploads/fotocaminhao.jpeg',
    description: `Caminhão equipado com guindaste hidráulico articulado (Munck). Ideal para elevação e movimentação de cargas pesadas, equipamentos e estruturas metálicas. Muito utilizado na construção civil, montagem de estruturas, fábricas, indústrias e obras em geral.
Oferece praticidade, força e segurança no içamento e transporte de materiais.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Munck – Caminhão com Guindaste.'
  }
];
