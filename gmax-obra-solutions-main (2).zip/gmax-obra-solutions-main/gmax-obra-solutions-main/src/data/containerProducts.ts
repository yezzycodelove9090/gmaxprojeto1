
export interface ContainerProduct {
  name: string;
  slug: string;
  heroImage: string;
  productImage: string;
  description: string;
  whatsappNumber: string;
  whatsappMessage: string;
}

export const containerProducts: ContainerProduct[] = [
  {
    name: 'Container Escritório',
    slug: 'container-escritorio',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Container escritório é a solução ideal para empresas que precisam de um espaço administrativo temporário ou permanente em obras, eventos ou projetos especiais.

Nossos containers escritório são totalmente equipados com:
- Isolamento térmico e acústico
- Sistema elétrico completo
- Iluminação LED
- Tomadas e pontos de energia
- Janelas com vidros temperados
- Porta de acesso com fechadura
- Piso em laminado ou vinyl
- Divisórias internas (conforme necessidade)

Perfeito para canteiros de obras, eventos corporativos, projetos temporários e expansão de escritórios.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Escritório.'
  },
  {
    name: 'Container Almoxarifado',
    slug: 'container-almoxarifado',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Container almoxarifado oferece a solução perfeita para armazenamento seguro de materiais, ferramentas e equipamentos.

Características principais:
- Estrutura robusta e segura
- Ventilação adequada
- Sistema de fechamento com cadeado
- Prateleiras e organizadores (opcional)
- Proteção contra intempéries
- Fácil acesso para carga e descarga
- Diferentes tamanhos disponíveis

Ideal para obras, indústrias, comércio e qualquer atividade que necessite de espaço para armazenamento organizado e seguro.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Almoxarifado.'
  },
  {
    name: 'Container Banheiro',
    slug: 'container-banheiro',
    heroImage: '/lovable-uploads/banheirocapa.jpeg',
    productImage: '/lovable-uploads/banheirocapa.jpeg',
    description: `Container banheiro é a solução sanitária completa para locais que precisam de instalações higiênicas de qualidade.

Equipado com:
- Vaso sanitário
- Pia com torneira
- Espelho
- Papel higiênico e saboneteira
- Iluminação interna
- Ventilação natural
- Porta com fechadura interna
- Piso antiderrapante
- Conexões hidráulicas completas

Perfeito para obras, eventos, canteiros e locais temporários que necessitam de facilidades sanitárias.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Banheiro.'
  },
  {
    name: 'Container Refeitório',
    slug: 'container-refeitorio',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Container refeitório proporciona um espaço confortável e higiênico para refeições em canteiros de obras e projetos.

Inclui:
- Mesas e bancos
- Geladeira
- Micro-ondas
- Pia para higienização
- Ar condicionado
- Iluminação adequada
- Ventilação natural
- Piso lavável
- Área para aquecimento de alimentos

Essencial para o bem-estar dos trabalhadores e cumprimento das normas de segurança do trabalho.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Refeitório.'
  },
  {
    name: 'Container Dormitório',
    slug: 'container-dormitorio',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Container dormitório oferece acomodação temporária confortável e segura para trabalhadores em projetos de longa duração.

Características:
- Beliches com colchões
- Roupeiros individuais
- Ar condicionado
- Iluminação individual
- Tomadas para cada leito
- Janelas com telas
- Porta com fechadura
- Piso adequado
- Ventilação cruzada

Ideal para obras em locais remotos, projetos de mineração e situações que requerem hospedagem temporária.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Container Dormitório.'
  },
  {
    name: 'Stand de Vendas',
    slug: 'container-stand-vendas',
    heroImage: '/lovable-uploads/capainternaconteiner.jpeg',
    productImage: '/lovable-uploads/conteiner01.jpeg',
    description: `Container stand de vendas é a solução móvel perfeita para pontos de venda temporários e eventos comerciais.

Equipado com:
- Balcão de atendimento
- Prateleiras para produtos
- Sistema elétrico completo
- Iluminação comercial
- Ventilação adequada
- Vitrine frontal
- Porta de acesso e janela de atendimento
- Visual atrativo e profissional

Perfeito para feiras, eventos, lançamentos imobiliários e pontos de venda temporários.`,
    whatsappNumber: '5518998181585',
    whatsappMessage: 'Olá! Gostaria de fazer um orçamento para Stand de Vendas.'
  }
];
