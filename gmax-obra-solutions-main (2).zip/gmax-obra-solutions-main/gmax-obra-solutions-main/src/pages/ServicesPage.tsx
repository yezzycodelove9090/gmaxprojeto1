
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import WhatsAppButton from '../components/WhatsAppButton';
import { Link } from 'react-router-dom';

const ServicesPage = () => {
  const services = [
    {
      id: 1,
      title: "Caçamba",
      slug: "cacamba",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Descarte de entulho rápido, prático e seguro. Entregamos e retiramos com agilidade."
    },
    {
      id: 2,
      title: "Container",
      slug: "container", 
      image: "https://images.unsplash.com/photo-1566207462340-1b71ee2b40d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Armazenamento seguro para obras e empresas."
    },
    {
      id: 3,
      title: "Caminhão Munck",
      slug: "caminhao-munck",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Içamento e transporte de cargas pesadas com total segurança."
    },
    {
      id: 4,
      title: "Banheiro",
      slug: "banheiro",
      image: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Solução sanitária prática para obras e eventos."
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-br from-primary to-blue-800">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
            Nossos Serviços
          </h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Soluções completas em locação de equipamentos para sua obra
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Link 
                key={service.id}
                to={`/servicos/${service.slug}`}
                className={`bg-white rounded-2xl overflow-hidden shadow-lg hover-lift cursor-pointer transition-all duration-300 ${
                  index % 2 === 0 ? 'animate-slide-in-left' : 'animate-slide-in-right'
                }`}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={`Locação de ${service.title} GMAX`}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute inset-0 bg-black/20"></div>
                  <h3 className="absolute bottom-4 left-4 text-white font-bold text-xl">
                    {service.title}
                  </h3>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                  <div className="mt-4 text-primary font-semibold hover:text-secondary transition-colors duration-200">
                    Saiba mais →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default ServicesPage;
