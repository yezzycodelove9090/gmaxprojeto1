
import React from 'react';
import ProductPage from '../components/ProductPage';
import { newProducts } from '../data/newProducts';

const BanheiroHidraulicoPage = () => {
  const product = newProducts.find(p => p.slug === 'banheiro-hidraulico');
  
  if (!product) {
    return <div>Produto não encontrado</div>;
  }

  return (
    <ProductPage
      title={product.name}
      heroImage={product.heroImage}
      productImage={product.productImage}
      description={product.description}
      whatsappNumber={product.whatsappNumber}
      whatsappMessage={product.whatsappMessage}
    />
  );
};

export default BanheiroHidraulicoPage;
