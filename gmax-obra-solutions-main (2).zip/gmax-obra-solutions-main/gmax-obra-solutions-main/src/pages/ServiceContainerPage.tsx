
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import WhatsAppButton from '../components/WhatsAppButton';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle } from 'lucide-react';

const ServiceContainerPage = () => {
  const containersGerais = [
    {
      title: "Container Almoxarifado",
      dimensions: "6 x 2,43",
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Depósito", 
      dimensions: "6 x 2,43",
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Mini",
      dimensions: "3 x 1,5", 
      whatsapp: "5518996221422",
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Refeitório",
      dimensions: "",
      whatsapp: "5518998181585", 
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Sanitário",
      dimensions: "",
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    }
  ];

  const containersEscritorios = [
    {
      title: "Container Small",
      dimensions: "3 x 1,5",
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Standard",
      dimensions: "6,05 x 2,43", 
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    },
    {
      title: "Container Max",
      dimensions: "12,00 x 2,43",
      whatsapp: "5518998181585",
      contact: "Fazer Orçamento"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Banner */}
      <section className="relative h-[60vh] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/lovable-uploads/capainternaconteiner.jpeg"
            alt="Locação de Container GMAX"
            className="w-full h-full object-cover blur-sm"
          />
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
          <div className="absolute inset-0 bg-black/20"></div>
        </div>

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white px-4 max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-6xl font-bold mb-4">
              Locação de Container
            </h1>
            <p className="text-xl lg:text-2xl">
              Armazenamento seguro e versátil para obras e empresas
            </p>
          </div>
        </div>
      </section>

      {/* Conteúdo */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-primary mb-6">
                Para quem é este serviço?
              </h2>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                Perfeito para obras que precisam de armazenamento seguro, empresas que necessitam
                de espaço extra temporário, eventos, depósitos provisórios e projetos de longa duração.
              </p>

              <h3 className="text-2xl font-bold text-primary mb-4">Como funciona:</h3>
              <div className="space-y-4 mb-8">
                {[
                  'Avaliamos sua necessidade e definimos o container ideal',
                  'Entregamos e posicionamos no local desejado',
                  'Fornecemos chaves e cadeados de segurança',
                  'Retiramos ao final do período contratado',
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <img
                src="/lovable-uploads/capainternaconteiner.jpeg"
                alt="Container para armazenamento"
                className="w-full rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Containers Gerais */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-primary text-center mb-12">
            Containers Gerais
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {containersGerais.map((container, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg text-center"
              >
                <h3 className="font-bold text-xl mb-4 text-primary">{container.title}</h3>
                {container.dimensions && (
                  <p className="text-gray-600 mb-4">Dimensões: {container.dimensions}</p>
                )}
                <a
                  href={`https://wa.me/${container.whatsapp}?text=Olá! Gostaria de fazer um orçamento para ${container.title}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-all duration-300 hover:scale-105 inline-block"
                >
                  {container.contact}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Containers Escritórios */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-primary text-center mb-12">
            Containers Escritórios
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {containersEscritorios.map((container, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg text-center"
              >
                <h3 className="font-bold text-xl mb-4 text-primary">{container.title}</h3>
                <p className="text-gray-600 mb-4">Dimensões: {container.dimensions}</p>
                <a
                  href={`https://wa.me/${container.whatsapp}?text=Olá! Gostaria de fazer um orçamento para ${container.title}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-all duration-300 hover:scale-105 inline-block"
                >
                 {container.contact}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-primary text-center mb-12">
            Benefícios e Diferenciais
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: '📦',
                title: 'Novos e Usados',
                desc: 'Containers em ótimo estado, novos e seminovos disponíveis',
              },
              {
                icon: '📏',
                title: 'Diversos Tamanhos',
                desc: '20 e 40 pés para atender diferentes volumes',
              },
              {
                icon: '🔒',
                title: 'Segurança Total',
                desc: 'Estrutura robusta e sistemas de fechamento seguros',
              },
              {
                icon: '🚚',
                title: 'Fácil Transporte',
                desc: 'Logística especializada para entrega e retirada',
              },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg text-center"
              >
                <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">{item.icon}</span>
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Fale com nossa equipe e solicite seu orçamento agora mesmo!
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Soluções de armazenamento personalizadas para sua necessidade
          </p>

          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/5518996221422?text=Olá! Gostaria de fazer um orçamento para locação de container."
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-700 transition-all duration-300 hover:scale-105"
            >
              FAZER ORÇAMENTO
            </a>

            <Link
              to="/servicos"
              className="bg-secondary text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar para Serviços
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default ServiceContainerPage;
