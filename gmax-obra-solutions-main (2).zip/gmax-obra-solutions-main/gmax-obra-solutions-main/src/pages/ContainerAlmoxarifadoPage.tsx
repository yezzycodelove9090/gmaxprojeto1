
import React from 'react';
import ProductPage from '../components/ProductPage';
import { containerProducts } from '../data/containerProducts';

const ContainerAlmoxarifadoPage = () => {
  const product = containerProducts.find(p => p.slug === 'container-almoxarifado');
  
  if (!product) {
    return <div>Produto não encontrado</div>;
  }

  return (
    <ProductPage
      title={product.name}
      heroImage={product.heroImage}
      productImage={product.productImage}
      description={product.description}
      whatsappNumber={product.whatsappNumber}
      whatsappMessage={product.whatsappMessage}
    />
  );
};

export default ContainerAlmoxarifadoPage;
